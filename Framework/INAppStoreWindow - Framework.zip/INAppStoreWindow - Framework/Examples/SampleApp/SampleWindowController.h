//
//  SampleWindowController.h
//  SampleApp
//
//  Created by Indragie Karunaratne on 11-02-23.
//  Copyright 2011-2014 Indragie Karunaratne. All rights reserved.
//
//  Licensed under the BSD 2-clause License. See LICENSE file distributed in the source
//  code of this project.
//


#import <Cocoa/Cocoa.h>


@interface SampleWindowController : NSWindowController {
@private

}

@end
