//
//  Document.h
//  SampleDocumentApp
//
//  Created by Indragie Karunaratne on 2012-08-29.
//  Copyright (c) 2012-2014 Indragie Karunaratne. All rights reserved.
//
//  Licensed under the BSD 2-clause License. See LICENSE file distributed in the source
//  code of this project.
//

#import <Cocoa/Cocoa.h>

@interface Document : NSDocument

@end
