//
//	INWindowBackgroundView+CoreUIRendering.h
//
//  Copyright (c) 2014 Petroules Corporation. All rights reserved.
//
//  Licensed under the BSD 2-clause License. See LICENSE file distributed in the source
//  code of this project.
//

#import "INAppStoreWindow.h"

@interface INWindowBackgroundView (CoreUIRendering)

@end
