//
//  ContentViewController.m
//  Copyright 2011-2014 Indragie Karunaratne. All rights reserved.
//

#import "ContentViewController.h"


@implementation ContentViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}


@end
