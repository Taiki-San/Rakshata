//
//  AlphaColorWell.h
//  PopoverSampleApp
//
//  Created by Indragie Karunaratne on 1/11/2014.
//

#import <Cocoa/Cocoa.h>

@interface AlphaColorWell : NSColorWell

@end
