//
//  main.m
//  PopoverSampleApp
//
//  Created by Indragie Karunaratne on 11-03-02.
//  Copyright 2011-2014 PCWiz Computer. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
