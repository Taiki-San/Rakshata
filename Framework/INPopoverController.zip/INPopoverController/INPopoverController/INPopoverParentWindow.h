//
//  INPopoverParentWindow.h
//  Copyright 2011-2014 Indragie Karunaratne. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface INPopoverParentWindow : NSWindow

- (BOOL)isReallyKeyWindow;

@end
